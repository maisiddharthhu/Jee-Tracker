# JEE Tracker PWA — How to Install on Your Phone

## Step 1: Upload to GitHub Pages (Free, Forever)

1. Go to https://github.com and sign up / log in
2. Click "+" → "New repository"
3. Name it: jee-tracker
4. Click "Create repository"
5. Click "uploading an existing file"
6. Upload ALL 4 files: index.html, manifest.json, sw.js, icon.svg
7. Click "Commit changes"
8. Go to Settings → Pages → Source → "Deploy from a branch" → main → / (root) → Save
9. Wait 1-2 minutes → your app is live at:
   https://YOUR_USERNAME.github.io/jee-tracker

## Step 2: Install on Android

1. Open Chrome on your phone
2. Go to: https://YOUR_USERNAME.github.io/jee-tracker
3. Tap the ⋮ menu → "Add to Home screen" OR
4. A banner will appear at the bottom saying "Install JEE Tracker" — tap it!
5. App icon appears on your home screen ✓

## Step 3: Install on iPhone

1. Open Safari on your iPhone
2. Go to: https://YOUR_USERNAME.github.io/jee-tracker
3. Tap the Share button (the box with an arrow)
4. Scroll down → tap "Add to Home Screen"
5. Tap "Add"
6. App icon appears on your home screen ✓

## Features
- Works OFFLINE after first load
- Saves your progress automatically (resets each day)
- Auto-scrolls to current time slot
- Real app feel — no browser bar visible
